﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecoveringDemo
{
    class Upholsterer
    {
        public void Recover()
        {
            Console.WriteLine("I am going back to my furniture");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecoveringDemo
{
    class RecoveringDemo
    {
        static void Main(string[] args)
        {
            Patient aPatient = new Patient();
            Upholsterer anUpholsterer = new Upholsterer();
            FootballPlayer aFootballPlayer = new FootballPlayer();

            Console.Write("The patient says: ");
            aPatient.Recover();

            Console.Write("The upholsterer says: ");
            anUpholsterer.Recover();

            Console.Write("The football player says: ");
            aFootballPlayer.Recover();

            Console.ReadKey();
        }
    }
}

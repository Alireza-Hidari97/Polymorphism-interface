﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalespersonDemo
{
    class GirlScout : Salesperson, ISellable
    {
        private int totalBoxes = 0;

        public int TotalBoxes
        {
            get
            {
                return totalBoxes;
            }
            set
            {
                totalBoxes = value;
            }
        }

        public GirlScout(string firstName, string lastName) : base(firstName, lastName)
        {

        }

        public void SalesSpeech()
        {
            Console.WriteLine("My cookies are the most delicious in the neighborhood");
        }

        public void MakeSale(int numberOfBoxes)
        {
            TotalBoxes += numberOfBoxes;
        }
    }
}

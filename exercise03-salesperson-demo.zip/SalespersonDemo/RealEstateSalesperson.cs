﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalespersonDemo
{
    class RealEstateSalesperson : Salesperson, ISellable
    {
        private double totalValueSold = 0;
        private double totalCommissionEarned = 0;
        private double commissionRate = 0;

        public double TotalValueSold
        {
            get
            {
                return totalValueSold;
            }
            set
            {
                totalValueSold = value;
            }
        }

        public double TotalCommissionEarned
        {
            get
            {
                return totalCommissionEarned;
            }
            set
            {
                totalCommissionEarned = value;
            }
        }

        public double CommissionRate
        {
            get
            {
                return commissionRate;
            }
            set
            {
                commissionRate = value;
            }
        }

        public RealEstateSalesperson(string firstName, string lastName, double commissionRate) : base(firstName, lastName)
        {
            CommissionRate = commissionRate;
        }

        public void SalesSpeech()
        {
            Console.WriteLine("My properties are the best ones in the market");
        }

        public void MakeSale(int houseValue)
        {
            TotalValueSold += houseValue;

            TotalCommissionEarned += houseValue * commissionRate;
        }

    }
}

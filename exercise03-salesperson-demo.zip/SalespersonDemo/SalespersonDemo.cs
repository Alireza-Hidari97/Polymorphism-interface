﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalespersonDemo
{
    class SalespersonDemo
    {
        static void Main(string[] args)
        {
            RealEstateSalesperson diane = new RealEstateSalesperson("Diane", "Kendall", 0.06);

            GirlScout mandy = new GirlScout("Mandy", "Hernandez");

            diane.SalesSpeech();
            mandy.SalesSpeech();

            diane.MakeSale(100_000);
            diane.MakeSale(150_000);

            mandy.MakeSale(2);
            mandy.MakeSale(10);
            mandy.MakeSale(4);

            Console.WriteLine("{0} sold {1} worth of real estate",
               diane.FullName(), diane.TotalValueSold.ToString("C0"));

            Console.WriteLine("At {0}%, the total commission earned is {1}",
               diane.CommissionRate * 100,
               diane.TotalCommissionEarned.ToString("C"));

            Console.WriteLine();

            Console.WriteLine("{0} sold {1} boxes of cookies",
               mandy.FullName(), mandy.TotalBoxes);

            Console.ReadKey();
        }
    }
}

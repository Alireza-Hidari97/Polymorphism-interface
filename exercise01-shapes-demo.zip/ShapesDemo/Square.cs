﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesDemo
{
    class Square : Rectangle
    {

        public new int Height
        {
            get
            {
                return height;
            }
            set
            {
                height = value;
                width = height;
                ComputeArea();
            }
        }

        public new int Width
        {
            get
            {
                return width;
            }
            set
            {
                width = value;
                height = width;
                ComputeArea();
            }
        }

        public Square(int width, int height) : base(width, width)
        {

        }

        public Square(int width) : base(width, width)
        {

        }

    }
}

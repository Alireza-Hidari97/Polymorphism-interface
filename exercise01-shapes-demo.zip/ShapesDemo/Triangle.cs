﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesDemo
{
    class Triangle : GeometricFigure
    {
        public override void ComputeArea()
        {
            area = width * (height/2);
        }

        public Triangle(int width, int height) : base(width, height)
        {
        }
    }
}

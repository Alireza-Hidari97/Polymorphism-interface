﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesDemo
{
    class ShapesDemo
    {
        static void Main(string[] args)
        {
            Rectangle rectangle1 = new Rectangle(3, 4);
            DisplayShapeStatistics(rectangle1);

            Square square1 = new Square(3, 4);
            DisplayShapeStatistics(square1);

            square1.Height = 20;
            DisplayShapeStatistics(square1);

            Square square2 = new Square(6);
            DisplayShapeStatistics(square2);

            square2.Height = 20;
            DisplayShapeStatistics(square2);

            Triangle triangle1 = new Triangle(3, 4);
            DisplayShapeStatistics(triangle1);

            triangle1.Height = 20;
            DisplayShapeStatistics(triangle1);

            Console.ReadKey();
        }

        static void DisplayShapeStatistics(GeometricFigure g)
        {
            Console.WriteLine(g.GetType() + " Height: " + g.Height +
               " Width: " + g.Width + " Area: " + g.Area);
        }

    }
}

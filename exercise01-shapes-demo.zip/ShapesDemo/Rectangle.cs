﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesDemo
{
    class Rectangle : GeometricFigure
    {
        public override void ComputeArea()
        {
            area = width * height;
        }

        public Rectangle(int width, int height) : base(width, height)
        {

        }

    }
}
